from Pe import Pe

def main():
    problem = Pe()
    problem.read()
    problem.solve()
    
if __name__=="__main__":
    main()